// task2_part2.cpp � Static scene: left triangle "shoots" a circle toward a right square.
// GL 3.3 Core, attributes: vPosition, vColor.
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <vector>
#include <cmath>
#include <cstdio>
#include <cstdlib>

static void check(bool ok, const char* msg) { if (!ok) { std::fprintf(stderr, "%s\n", msg); std::exit(1); } }
static void framebuffer_size_callback(GLFWwindow*, int w, int h) { glViewport(0, 0, w, h); }
constexpr float PI = 3.14159265358979323846f;

static const char* VS = R"(#version 330 core
layout (location=0) in vec2 vPosition;
layout (location=1) in vec3 vColor;
out vec3 color;
void main(){
    color = vColor;
    gl_Position = vec4(vPosition, 0.0, 1.0);
}
)";

static const char* FS = R"(#version 330 core
in vec3 color;
out vec4 FragColor;
void main(){ FragColor = vec4(color, 1.0); }
)";

static GLuint sh(GLenum t, const char* s) {
    GLuint id = glCreateShader(t);
    glShaderSource(id, 1, &s, nullptr);
    glCompileShader(id);
    GLint ok; glGetShaderiv(id, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024]; glGetShaderInfoLog(id, 1024, nullptr, log);
        std::fprintf(stderr, "Shader error:\n%s", log); std::exit(1);
    }
    return id;
}
static GLuint prog(const char* vs, const char* fs) {
    GLuint v = sh(GL_VERTEX_SHADER, vs), f = sh(GL_FRAGMENT_SHADER, fs);
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024]; glGetProgramInfoLog(p, 1024, nullptr, log);
        std::fprintf(stderr, "Link error:\n%s", log); std::exit(1);
    }
    glDeleteShader(v); glDeleteShader(f);
    return p;
}

struct Mesh { GLuint vao = 0, vbo = 0; GLsizei count = 0; GLenum mode = GL_TRIANGLES; };
static Mesh makeMesh(const std::vector<float>& interleaved, GLenum mode) {
    Mesh m; m.mode = mode; m.count = (GLsizei)(interleaved.size() / 5); // 2 pos + 3 color
    glGenVertexArrays(1, &m.vao);
    glGenBuffers(1, &m.vbo);
    glBindVertexArray(m.vao);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, interleaved.size() * sizeof(float), interleaved.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);                 glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(2 * sizeof(float))); glEnableVertexAttribArray(1);
    glBindVertexArray(0);
    return m;
}

int main() {
    check(glfwInit(), "glfwInit failed");
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    GLFWwindow* win = glfwCreateWindow(500, 500, "Task 2 � Part 2 (static)", nullptr, nullptr);
    check(win != nullptr, "glfwCreateWindow failed");
    glfwMakeContextCurrent(win);
    glfwSetFramebufferSizeCallback(win, framebuffer_size_callback);
    check(gladLoadGLLoader((GLADloadproc)glfwGetProcAddress), "gladLoadGLLoader failed");
    glViewport(0, 0, 500, 500);

    GLuint p = prog(VS, FS);

    // --- Right target: square (center ~ +0.65, 0), size ~0.30
    float sx = 0.65f, sy = 0.0f, s = 0.30f;
    std::vector<float> square = {
        sx - s,sy - s,  0.55f,0.80f,0.95f,
        sx + s,sy - s,  0.45f,0.75f,0.90f,
        sx + s,sy + s,  0.50f,0.85f,0.95f,

        sx - s,sy - s,  0.55f,0.80f,0.95f,
        sx + s,sy + s,  0.50f,0.85f,0.95f,
        sx - s,sy + s,  0.45f,0.75f,0.90f
    };
    Mesh squareM = makeMesh(square, GL_TRIANGLES);

    // --- Left shooter: triangle pointing right
    std::vector<float> tri = {
        -0.90f,-0.12f,  0.90f,0.45f,0.20f,
        -0.90f, 0.12f,  0.90f,0.45f,0.20f,
        -0.60f, 0.00f,  0.98f,0.62f,0.25f
    };
    Mesh triM = makeMesh(tri, GL_TRIANGLES);

    // --- Bullet: fixed circle between triangle and square (center near x=-0.10, y=0)
    std::vector<float> circle;
    const int SEG = 64;
    float cx = -0.10f, cy = 0.00f, r = 0.07f;
    // center vertex (for TRIANGLE_FAN)
    circle.insert(circle.end(), { cx,cy, 1.00f,0.95f,0.20f });
    for (int i = 0; i <= SEG; ++i) {
        float t = (float)i * 2.0f * PI / SEG;
        float x = cx + r * std::cos(t);
        float y = cy + r * std::sin(t);
        // slight orange rim
        circle.insert(circle.end(), { x,y, 1.00f,0.82f + 0.12f * std::cos(t), 0.25f });
    }
    // Build TRIANGLE_FAN VAO/VBO
    Mesh bulletM; bulletM.mode = GL_TRIANGLE_FAN;
    bulletM.count = (GLsizei)(circle.size() / 5);
    glGenVertexArrays(1, &bulletM.vao);
    glGenBuffers(1, &bulletM.vbo);
    glBindVertexArray(bulletM.vao);
    glBindBuffer(GL_ARRAY_BUFFER, bulletM.vbo);
    glBufferData(GL_ARRAY_BUFFER, circle.size() * sizeof(float), circle.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);                 glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(2 * sizeof(float))); glEnableVertexAttribArray(1);
    glBindVertexArray(0);

    while (!glfwWindowShouldClose(win)) {
        if (glfwGetKey(win, GLFW_KEY_ESCAPE) == GLFW_PRESS) glfwSetWindowShouldClose(win, 1);

        glClearColor(0.08f, 0.10f, 0.14f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glUseProgram(p);

        glBindVertexArray(squareM.vao); glDrawArrays(squareM.mode, 0, squareM.count);
        glBindVertexArray(triM.vao);    glDrawArrays(triM.mode, 0, triM.count);
        glBindVertexArray(bulletM.vao); glDrawArrays(bulletM.mode, 0, bulletM.count);

        glfwSwapBuffers(win);
        glfwPollEvents();
    }

    auto del = [&](Mesh& m) { glDeleteBuffers(1, &m.vbo); glDeleteVertexArrays(1, &m.vao); };
    del(squareM); del(triM); del(bulletM);
    glDeleteProgram(p);
    glfwTerminate();
    return 0;
}
