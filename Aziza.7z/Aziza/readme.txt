Aziza OpenGL Project
====================

Описание
--------
Этот проект написан на C++ и использует OpenGL, GLFW и GLAD.  
Сборка выполняется с помощью CMake и MinGW (MSYS2).

Структура проекта
-----------------
Aziza/
 ├─ src/                - исходные файлы проекта (.cpp)
 │   ├─ main.cpp
 │   ├─ bluesquare.cpp
 │   ├─ redtriangl.cpp
 │   └─ ...
 ├─ deps/               - сторонние библиотеки
 │   └─ glad/
 │       ├─ include/glad/glad.h
 │       └─ src/glad.c
 ├─ CMakeLists.txt      - файл для CMake
 └─ build/              - создаётся автоматически при сборке

Установка зависимостей (MSYS2)
------------------------------
1. Установи MSYS2: https://www.msys2.org
2. Открой MSYS2 MinGW64 (не MSYS!).
3. Установи пакеты:
   pacman -Syu
   pacman -S mingw-w64-x86_64-toolchain
   pacman -S mingw-w64-x86_64-cmake
   pacman -S mingw-w64-x86_64-glfw

Подготовка GLAD
---------------
1. Скачай GLAD с https://glad.dav1d.de/ (API: OpenGL, версия 4.1 или выше).
2. Скопируй файлы в проект:
   - glad.h → Aziza/deps/glad/include/glad/glad.h
   - glad.c → Aziza/deps/glad/src/glad.c

Сборка проекта
--------------
   cd Aziza
   mkdir build
   cd build
   cmake .. -G "MinGW Makefiles"
   mingw32-make

Запуск
------
После сборки будет создан файл aziza.exe в папке build.
Запуск:
   ./aziza.exe

Автор
-----
Проект создан для учебных целей.